#pragma once
#include "afxwin.h"


// COAuthTesterDlg dialog

class COAuthTesterDlg : public CDialog
{
	DECLARE_DYNAMIC(COAuthTesterDlg)

public:
	COAuthTesterDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~COAuthTesterDlg();

// Dialog Data
	enum { IDD = IDD_OAUTHTESTERDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	CEdit m_edResult;
	CEdit m_edRequest;
};
