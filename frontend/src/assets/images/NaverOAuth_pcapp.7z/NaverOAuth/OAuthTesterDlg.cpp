// OAuthTesterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "NaverOAuth.h"
#include "OAuthTesterDlg.h"
#include "NaverOAuthDlg.h"
#include "afxdialogex.h"


// COAuthTesterDlg dialog

IMPLEMENT_DYNAMIC(COAuthTesterDlg, CDialog)

COAuthTesterDlg::COAuthTesterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COAuthTesterDlg::IDD, pParent)
{

}

COAuthTesterDlg::~COAuthTesterDlg()
{
}

void COAuthTesterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ED_RESULT, m_edResult);
	DDX_Control(pDX, IDC_ED_REQUEST, m_edRequest);
}


BEGIN_MESSAGE_MAP(COAuthTesterDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &COAuthTesterDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// COAuthTesterDlg message handlers


void COAuthTesterDlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	CNaverOAuthDlg Dlg;
	int nRet = Dlg.DoModal();
	if(nRet == IDOK)
	{
		m_edRequest.SetWindowText(Dlg.GetRequestUrl());
		CString szResult;
		szResult = _T("Result Code = ");
		szResult += Dlg.GetResultCode();
		szResult += _T("\r\n");
		szResult += _T("Code = ");
		szResult += Dlg.GetCode();
		szResult += _T("\r\n");
		szResult += _T("State = ");
		szResult += Dlg.GetState();
		szResult += _T("\r\n");
		m_edResult.SetWindowText(szResult);

	}
}

