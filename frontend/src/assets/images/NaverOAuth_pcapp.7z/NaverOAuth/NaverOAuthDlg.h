
// NaverOAuthDlg.h : ��� ����
//

#pragma once


// CNaverOAuthDlg ��ȭ ����
class CNaverOAuthDlg : public CDHtmlDialog
{
// �����Դϴ�.
public:
	CNaverOAuthDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_NAVEROAUTH_DIALOG, IDH = 0 };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.

	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);


// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
public:
	virtual void OnDocumentComplete(LPDISPATCH pDisp, LPCTSTR szUrl);
	virtual void OnNavigateComplete(LPDISPATCH pDisp, LPCTSTR szUrl);
	
	void SetRequestUrl(CString szURl) { m_RequestURl = szURl; }
	void SetResultCode(CString szResultCode) { m_ResultCode = szResultCode; }
	void SetCode(CString szCode) { m_Code = szCode; }
	void SetState(CString szState) { m_State = szState; }

	CString GetRequestUrl() { return m_RequestURl; }
	CString GetResultCode() { return m_ResultCode; }
	CString GetCode() { return m_Code; }
	CString GetState() { return m_State; }
private:
	CString ExtractUrl( LPCTSTR szUrl );
	BOOL CallbackUrlExtractHtml(LPDISPATCH pDisp, LPCTSTR szUrl);

	CString m_RequestURl;
	CString m_strStateCode;
	CString m_ResultCode;
	CString m_Code;
	CString	m_State; 
};
